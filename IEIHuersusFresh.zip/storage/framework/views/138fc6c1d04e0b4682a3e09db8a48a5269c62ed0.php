<?php  $title="$page->title";  ?>

<?php $__env->startSection('content'); ?>    
    <!-- Page Title ============================================= -->
    <section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url(<?php echo e(asset('/media/images/'.$page->breadcrumbs_background)); ?>); repeat: no-repeat; padding: 120px 0;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
        <div class="container clearfix text-white">
            <h1><?php echo e($page->title); ?></h1>
            <span><?php echo e($page->subtitle); ?></span>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Home</a></li>
                <?php if(!empty($page->parent)): ?>
                <li class="breadcrumb-item" aria-current="page"><?php echo e($page->parent); ?></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title); ?></li>
            </ol>
        </div>
    </section><!-- #page-title end -->
    <!-- Page Sub Menu =============================================
    <div id="page-menu">
        <div id="page-menu-wrap">
            <div class="container clearfix">
                <div class="menu-title"> <span><?php echo e($page->alias); ?></span></div>
                <div id="page-submenu-trigger"><i class="icon-reorder"></i></div>
            </div>
        </div>
    </div> #page-menu end -->
    <!-- Content ============================================= -->
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">
                <div class="clear"></div>
                <!-- Service centers Info ============================================= -->
                <div id="serv-centr" class="row clear-bottommargin">
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 bottommargin clearfix">
                        <div class="feature-box fbox-center fbox-bg fbox-plain">
                            <div class="fbox-icon">
                                <a href="#"><i class="icon-map-marker2"></i></a>
                            </div>
                            <h3><?php echo e($branch->title); ?><span class="subtitle"><?php echo e($branch->state); ?></span></h3>
                            <div class="">
                                <address> 
                                    <strong>Personnel: <span class="subtitle"><?php echo e($branch->personnel); ?></span></strong><br>
                                    <?php echo $branch->address; ?>

                                </address>
                                <abbr title="Phone Number"><strong>Phone:</strong></abbr> <?php echo e($branch->mobile); ?><br>
                                <?php if(!empty($branch->phone)): ?>
                                <abbr title="Phone Number"><strong>Phone:</strong></abbr> <?php echo e($branch->phone); ?><br>
                                <?php endif; ?>
                            </div><!-- .address end -->
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
        </div>
    </section><!-- #content end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>