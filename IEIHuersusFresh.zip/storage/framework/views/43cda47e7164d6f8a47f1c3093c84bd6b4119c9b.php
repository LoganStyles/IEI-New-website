<?php  $title="$page->title";  ?>

<?php $__env->startSection('content'); ?>    
    <!-- Page Title ============================================= -->
    <section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url(<?php echo e(asset('/media/images/'.$page->breadcrumbs_background)); ?>); repeat: no-repeat; padding: 120px 0;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
        <div class="container clearfix text-white">
            <h1><?php echo e($page->title); ?></h1>
            <span><?php echo e($page->subtitle); ?></span>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Home</a></li>
                <?php if(!empty($page->parent)): ?>
                <li class="breadcrumb-item" aria-current="page"><?php echo e($page->parent); ?></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title); ?></li>
            </ol>
        </div>
    </section><!-- #page-title end -->
    <!-- Page Sub Menu =============================================
    <div id="page-menu">
        <div id="page-menu-wrap">
            <div class="container clearfix">
                <div class="menu-title"> <span><?php echo e($page->alias); ?></span></div>
                <div id="page-submenu-trigger"><i class="icon-reorder"></i></div>
            </div>
        </div>
    </div> #page-menu end -->
    <!-- Content ============================================= -->
    <section id="content">
        <div id="faq" class="content-wrap">
            <div class="container clearfix">
                <h3><?php echo $page->content_title; ?></h3>
                <div class="divider"><i class="icon-circle"></i></div>
                <div class="col_half nobottommargin">

                    <h4>General FAQs <small>(<?php echo e(count($general)); ?>)</small></h4>
                    <div class="accordion accordion-border clearfix" data-state="closed">
                        <?php $__currentLoopData = $general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="acctitle"><i class="acc-closed icon-question-sign"></i><i class="acc-open icon-question-sign"></i><?php echo $faq->question; ?></div>
                        <div class="acc_content clearfix"><?php echo $faq->answer; ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>



                    <h4 class="topmargin">My Retirement Savings Account <small>(<?php echo e(count($savings)); ?>)</small></h4>
                    <div class="accordion accordion-border nobottommargin clearfix" data-state="closed">
                        <?php $__currentLoopData = $savings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="acctitle"><i class="acc-closed icon-question-sign"></i><i class="acc-open icon-question-sign"></i><?php echo $faq->question; ?></div>
                        <div class="acc_content clearfix"><?php echo $faq->answer; ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>

                </div>

                <div class="col_half nobottommargin col_last">
                    <h4>About My Retirement <small>(<?php echo e(count($retirement)); ?>)</small></h4>

                    <div class="accordion accordion-border clearfix" data-state="closed">
                        <?php $__currentLoopData = $retirement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="acctitle"><i class="acc-closed icon-question-sign"></i><i class="acc-open icon-question-sign"></i><?php echo $faq->question; ?></div>
                        <div class="acc_content clearfix"><?php echo $faq->answer; ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>

                    <h4 class="topmargin">Multi Funds <small>(<?php echo e(count($multifunds)); ?>)</small></h4>
                    <div class="accordion accordion-border nobottommargin clearfix" data-state="closed">
                        <?php $__currentLoopData = $multifunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="acctitle"><i class="acc-closed icon-question-sign"></i><i class="acc-open icon-question-sign"></i><?php echo $faq->question; ?></div>
                        <div class="acc_content clearfix"><?php echo $faq->answer; ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                    </div>



                    <h4 class="topmargin">Micro Pension Funds <small>(<?php echo e(count($pension)); ?>)</small></h4>
                    <div class="accordion accordion-border nobottommargin clearfix" data-state="closed">
                        <?php $__currentLoopData = $pension; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="acctitle"><i class="acc-closed icon-question-sign"></i><i class="acc-open icon-question-sign"></i><?php echo $faq->question; ?></div>
                        <div class="acc_content clearfix"><?php echo $faq->answer; ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>

                </div>

            </div>
        </div>
    </section><!-- #content end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>