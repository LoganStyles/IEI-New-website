<?php echo $__env->make('office.templates.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
    <?php echo $__env->make('office.templates.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
<?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
    <?php echo $__env->make('office.templates.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
