<?php $__env->startSection('content'); ?>
<div class="card border-light mb-3 mt-3">
    <div class="card-header"><strong>Profile</strong></div>
        <div class="card-body">
            <div class="row">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success w-100">
                        <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger w-100">
                        <?php if(is_array(session()->get('error'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('error')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <form class="form-horizontal  col-md-12" method="POST" action="<?php echo e(route('office.users.profile')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group<?php echo e($errors->has('firstName') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-12 control-label pl-0">First Name</label>

                        <div class="">
                            <input id="firstName" type="text" class="form-control" name="firstName" value="<?php echo e($users->firstName); ?>" required autofocus>

                            <?php if($errors->has('firstName')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('firstName')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('lastName') ? ' has-error' : ''); ?>">
                        <label for="lastName" class="col-md-12 control-label pl-0">Last Name</label>
                        <input id="lastName" type="text" class="form-control" name="lastName" value="<?php echo e($users->lastName); ?>" required>
                        <?php if($errors->has('lastName')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('lastName')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-md-12 control-label pl-0">E-Mail Address</label>
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e($users->email); ?>" required>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                        <label for="username" class="col-md-12 control-label pl-0">Username</label>
                        <input id="username" type="text" class="form-control" name="username" value="<?php echo e($users->username); ?>" required>
                        <?php if($errors->has('username')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> col-md-6">
                            <label for="password" class="col-md-12 control-label pl-0">Password</label>
                            <input id="password" type="password" class="form-control" name="password">
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
    
                        <div class="form-group col-md-6">
                            <label for="password-confirm" class="col-md-12 control-label pl-0">Confirm Password</label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                        </div>
                    </div>


                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Save Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>