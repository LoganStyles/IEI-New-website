<?php  $title="$homes->title";  ?>
<?php  $author="$homes->author";  ?>
<?php  $keywords="$homes->keywords";  ?>
<?php  $description="$homes->description";  ?>

<?php $__env->startSection('content'); ?>
    <!-- Slider ============================================= -->
    <section id="slider" class="slider-element full-screen clearfix">
        <!-- Flex Slide ============================================= -->
        <div class="fslider full-screen" data-speed="1500" data-autoplay="true" data-pause="6000" data-animation="fade" data-arrows="false" data-pagi="false" data-hover="false" data-touch="false">
            <div class="flexslider">
                <div class="slider-wrap">
                <div class="slide full-screen" style="background: url(<?php echo e(asset('/media/images/slider/')); ?>/<?php echo e($homes->slide_one_image); ?>) center center; background-size: cover;">
                        <div class="vertical-middle">
                            <div class="container dark clearfix">
                                <div class="row justify-content-center clearfix">
                                    <div class="col-md-7">
                                        <div class="heading-block nobottomborder parallax nobottommargin" data-0="opacity: 1;margin-top:0px" data-800="opacity: 0.2;margin-top:150px">
                                            <p><?php echo e($homes->slide_one_p); ?></p>
                                            <h2 class="mb-4"><?php echo e($homes->slide_one_h2); ?></h2>
                                            <?php if(!empty($homes->slide_one_url)): ?>
                                            <a href="<?php echo e((strpos($homes->slide_one_url, 'http') !== false)?'': url('').'/'); ?><?php echo e($homes->slide_one_url); ?>" class="button button-border button-circle button-fill fill-from-bottom button-white button-light nott t400"><span>View Details</span></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5 align-self-lg-center align-self-md-baseline">
                                        <a href="#" class="" data-lightbox="iframe"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="slide full-screen" style="background: url(<?php echo e(asset('/media/images/slider/')); ?>/<?php echo e($homes->slide_two_image); ?>) center center; background-size: cover;">
                        <div class="vertical-middle">
                            <div class="container dark clearfix">
                                <div class="row justify-content-center clearfix">
                                    <div class="col-md-7">
                                        <div class="heading-block nobottomborder parallax nobottommargin" data-0="opacity: 1;margin-top:0px" data-800="opacity: 0.2;margin-top:150px">
                                            <p><?php echo e($homes->slide_two_p); ?></p>
                                            <h2 class="mb-4"><?php echo e($homes->slide_two_h2); ?></h2>                                            
                                            <?php if(!empty($homes->slide_two_url)): ?>
                                            <a href="<?php echo e((strpos($homes->slide_two_url, 'http') !== false)?'': url('').'/'); ?><?php echo e($homes->slide_two_url); ?>" class="button button-border button-circle button-fill fill-from-bottom button-white button-light nott t400"><span>View Details</span></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5 align-self-lg-center align-self-md-baseline">
                                        <a href="#" class="" data-lightbox="iframe"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="slide full-screen" style="background: url(<?php echo e(asset('/media/images/slider/')); ?>/<?php echo e($homes->slide_three_image); ?>) center center; background-size: cover;">
                        <div class="vertical-middle">
                            <div class="container dark clearfix">
                                <div class="row justify-content-center clearfix">
                                    <div class="col-md-7">
                                        <div class="heading-block nobottomborder parallax nobottommargin" data-0="opacity: 1;margin-top:0px" data-800="opacity: 0.2;margin-top:150px">
                                            <p><?php echo e($homes->slide_three_p); ?></p>
                                            <h2 class="mb-4"><?php echo e($homes->slide_three_h2); ?></h2>
                                            <?php if(!empty($homes->slide_three_url)): ?>
                                            <a href="<?php echo e((strpos($homes->slide_three_url, 'http') !== false)?'': url('').'/'); ?><?php echo e($homes->slide_three_url); ?>" class="button button-border button-circle button-fill fill-from-bottom button-white button-light nott t400"><span>View Details</span></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5 align-self-lg-center align-self-md-baseline">
                                        <a href="" class="" data-lightbox="iframe"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(!empty($homes->slide_four_image)): ?>
                    <div class="slide full-screen" style="background: url(<?php echo e(asset('/media/images/slider/')); ?>/<?php echo e($homes->slide_four_image); ?>) center center; background-size: cover;">
                        <div class="vertical-middle">
                            <div class="container dark clearfix">
                                <div class="row justify-content-center clearfix">
                                    <div class="col-md-7">
                                        <div class="heading-block nobottomborder parallax nobottommargin" data-0="opacity: 1;margin-top:0px" data-800="opacity: 0.2;margin-top:150px">
                                            <p><?php echo e($homes->slide_four_p); ?></p>
                                            <h2 class="mb-4"><?php echo e($homes->slide_four_h2); ?></h2>
                                            <?php if(!empty($homes->slide_four_url)): ?>
                                            <a href="<?php echo e((strpos($homes->slide_four_url, 'http') !== false)?'': url('').'/'); ?><?php echo e($homes->slide_four_url); ?>" class="button button-border button-circle button-fill fill-from-bottom button-white button-light nott t400"><span>View Details</span></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5 align-self-lg-center align-self-md-baseline">
                                        <a href="" class="" data-lightbox="iframe"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty($homes->slide_five_image)): ?>
                    <div class="slide full-screen" style="background: url(<?php echo e(asset('/media/images/slider/')); ?>/<?php echo e($homes->slide_five_image); ?>) center center; background-size: cover;">
                        <div class="vertical-middle">
                            <div class="container dark clearfix">
                                <div class="row justify-content-center clearfix">
                                    <div class="col-md-7">
                                        <div class="heading-block nobottomborder parallax nobottommargin" data-0="opacity: 1;margin-top:0px" data-800="opacity: 0.2;margin-top:150px">
                                            <p><?php echo e($homes->slide_five_p); ?></p>
                                            <h2 class="mb-4"><?php echo e($homes->slide_five_h2); ?></h2>
                                            <?php if(!empty($homes->slide_five_url)): ?>
                                            <a href="<?php echo e((strpos($homes->slide_five_url, 'http') !== false)?'': url('').'/'); ?><?php echo e($homes->slide_five_url); ?>" class="button button-border button-circle button-fill fill-from-bottom button-white button-light nott t400"><span>View Details</span></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5 align-self-lg-center align-self-md-baseline">
                                        <a href="" class="" data-lightbox="iframe"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Slider Bottom Content
        ============================================= -->
        <div class="slider-product-desc dark">
            <div class="row nomargin d-none d-md-flex clearfix">
                <div class="col-md-6" style="border-right: 1px dotted rgba(255,255,255,0.5);">
                    <div class="feature-box fbox-dark fbox-plain nobottommargin">
                        <div class="fbox-icon">
                            <a href="#"><i class="icon-money"></i></a>
                        </div>
                        <h3 class="t400 mb-3"><?php echo e($homes->widget_one_title); ?></h3>
                        <p class="d-none d-lg-block"><?php echo $homes->widget_one_desc; ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-box fbox-dark fbox-plain nobottommargin">
                        <div class="fbox-icon">
                            <a href="#"><i class="icon-wallet1"></i></a>
                        </div>
                        <h3 class="t400 mb-3"><?php echo e($homes->widget_two_title); ?></h3>
                        <ul class="d-none d-lg-block">
                        <li class="latest_unit">RSA Fund I: <span id="price_fund1"></span></li>
                        <li class="latest_unit">RSA Fund II: <span id="price_fund2"></span></li>
                        <li class="latest_unit">RSA Fund III: <span id="price_fund3"></span></li>
                        <li class="latest_unit">RSA Fund IV: <span id="price_fund4"></span></li>
                        <li><a class="btn btn-primary" href="http://iei.huesrus.com/resources/prices">View History</a></li>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CORE SERVICES -->
    <section id="iei-services">
        <div class="spacing pt-5">
            <div class="container">
                <div class="sec-tl2 text-center">
                    <i>CORE SERVICES</i>
                    <h2 class="no-bf" itemprop="headline"><?php echo $homes->services_title; ?></h2>
                </div>
                <div class="remove-ext3">
                    <div class="row">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 col-lg-4">
                            <div class="fea-bx">
                                <img src="<?php echo e(asset('/media/images/misc/').'/'.$service->image); ?>" alt="Collecting for Retirment" itemprop="image" height="60"> 
                                <div class="fea-bx-inf">
                                    <a href="<?php echo e((strpos($service->link, 'http') !== false)?$service->link: url('').'/'.$service->link); ?>"><h4 itemprop="headline"><?php echo e($service->title); ?></h4></a>
                                    <p itemprop="description"><?php echo e($service->description); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- #content end -->
    <!--================================ START ADDITIONAL SERVICES AREA =================================-->
    <section class="think-area responsive-content think--area area-padding" style="background-image:url(<?php echo e(asset('/media/images/mesh-bg2.png')); ?>);">
    <div class="think-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="iei-heading inspire-title2 mb-40px">
                    <h2 class="iei__title third__title "><?php echo $homes->work_with_title; ?></h2>
                </div><!-- end avivon-heading -->
                <div class="iei-btn">
                    <a href="<?php echo e((strpos($homes->work_with_url, 'http') !== false)?'': url('').'/'); ?><?php echo e($homes->work_with_url); ?>" class="iei__btn">Get started <span class="fontello icon-angle-double-right"></span></a>
                </div><!-- end avivon-btn -->
            </div><!-- end col-md-12 -->
        </div><!-- end row -->
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="think-column-box boxed-bg-3" style="background-image: url(<?php echo e(asset('/media/images/')); ?>/<?php echo e($homes->work_with_one_image); ?>">
                    <div class="think-boxed">
                        <h3 class="boxed__title"><?php echo e($homes->work_with_widget_one); ?></h3>
                        <a href="<?php echo e(url('pension/schemes')); ?>" class="boxed__btn">read more
                            <span class="fontello icon-angle-double-right"></span>
                        </a>
                    </div><!-- end think-boxed -->
                </div><!-- end think-column -->
            </div><!-- end col-md-6 -->
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="think-column-box boxed-bg-4" style="background-image: url(<?php echo e(asset('/media/images/')); ?>/<?php echo e($homes->work_with_two_image); ?>">
                    <div class="think-boxed">
                        <h3 class="boxed__title"><?php echo e($homes->work_with_widget_two); ?></h3>
                        <a href="<?php echo e(url('investment/strategy')); ?>" class="boxed__btn">read more
                            <span class="fontello icon-angle-double-right"></span>
                        </a>
                    </div><!-- end think-boxed -->
                </div><!-- end think-column -->
            </div><!-- end col-md-6 -->
        </div><!-- end row -->
    </div><!-- end container -->
    </div><!-- end think-fluid -->
    </section><!-- end think-area -->
    <!--================================ END ADDITIONAL SERVICES AREA=================================-->

    <!-- IEI TESTIMONIALS Content ============================================= -->
    <section id="content" style="background-color: #F9F9F9; padding: 20px;">
            <div class="container clearfix">
                <h3 class="center"><?php echo e($homes->testimonial_title); ?></h3>

                <div id="oc-testi" class="owl-carousel testimonials-carousel carousel-widget" data-margin="20" data-items-sm="1" data-items-md="2" data-items-xl="3">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                    <div class="oc-item">
                        <div class="testimonial">
                            <div class="testi-image">
                                <a href="#"><img src="<?php echo e(asset('/media/images/testimonials/')); ?>/<?php echo e($testimony->image); ?>" alt="<?php echo e($testimony->name); ?> Testimony"></a>
                            </div>
                            <div class="testi-content">
                                <p><?php echo $testimony->testimony; ?></p>
                                <div class="testi-meta"><?php echo e($testimony->name); ?>

                                    <span><?php echo e($testimony->company); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="#" data-toggle="modal" data-target="#testimonyModal" class="button button-3d button-rounded button-blue center reviewing">leave a review</a>
            </div>
    </section><!-- end iei testimonials -->

    <!-- begin iei awards ============================================= -->
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">

                <div class="fancy-title title-center title-dotted-border topmargin-sm">
                    <h3><?php echo e($homes->award_title); ?></h3>
                </div>

                <div class="owl-carousel image-carousel carousel-widget flip-card-wrapper clearfix" data-margin="20" data-nav="true" data-pagi="false" data-items-xs="2" data-items-sm="2" data-items-md="2" data-items-lg="3" data-items-xl="3" style="overflow: visible;">
                    <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flip-card">
                        <div class="flip-card-front dark" style="background-image: url(<?php echo e(asset('/media/images/awards/')); ?>/<?php echo e($award->image); ?>)">
                            <div class="flip-card-inner">
                                <div class="card nobg noborder">
                                    <div class="card-body">
                                        <h3 class="card-title mb-0"><?php echo e($award->title); ?></h3>
                                        <span class="font-italic"><?php echo e($award->award); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flip-card-back bg-warning no-after">
                            <div class="flip-card-inner">
                                <p class="mb-2 text-white"><?php echo e($award->description); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </section><!-- end iei awards section -->

    <!-- CAVEAT MODAL ============================================= -->
    <section id="content">
        <div class="<?php echo e((session()->has('success') || session()->has('error'))?'':'modal-on-load'); ?>" data-target="#myModal1"></div>

        <!-- Modal -->
        <div class="modal1 mfp-hide" id="myModal1">
            <div class="block divcenter" style="background-color: #FFF; max-width: 500px;">
                <div class="center" style="padding: 50px;">
                    <h3 style="color: #f1222a;"><?php echo $homes->notice_title; ?></h3>
                    <p class="nobottommargin"><?php echo $homes->notice_body; ?></p>
                </div>
                <div class="section center nomargin" style="padding: 30px;">
                    <a href="#" class="button button-large button-rounded ccaveat" onClick="$.magnificPopup.close();return false;">Close</a>
                </div>
            </div>
        </div>
    </section><!-- end CAVEAT MODAL -->

  <!-- Modal Contact Form ============================================= -->
    <section>
        <div class="modal fade <?php echo e((session()->has('success') || session()->has('error')? 'show':'')); ?>" style="<?php echo e((session()->has('success') || session()->has('error')? 'padding-right: 17px; display: block;':'')); ?>" id="testimonyModal" tabindex="-1" role="dialog" aria-labelledby="testimonyModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="testimonyModalLabel">Send Us your feedback</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success w-100">
                                <?php if(is_array(session()->get('success'))): ?>
                                <ul>
                                    <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($message); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php else: ?>
                                    <?php echo e(session()->get('success')); ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger w-100">
                                <?php if(is_array(session()->get('error'))): ?>
                                <ul>
                                    <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($message); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php else: ?>
                                    <?php echo e(session()->get('error')); ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div class="contact-widget">
                            <div class="contact-form-result"></div>
                            <form class="nobottommargin" id="iei-testimony" name="iei-testimony" action="" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-process"></div>
                                <div class="col_half">
                                    <label for="iei-testimony-name">Name <small>*</small></label>
                                    <input type="text" id="iei-testimony-name" name="name" value="<?php echo e(old('name')); ?>" required="required" class="sm-form-control required" />
                                </div>

                                <div class="col_half col_last">
                                    <label for="iei-testimony-email">Email <small>*</small></label>
                                    <input type="email" id="iei-testimonyemail" name="email" value="<?php echo e(old('email')); ?>" required="required" class="required email sm-form-control" />
                                </div>

                                <div class="clear"></div>

                                <div class="col_half">
                                    <label for="iei-testimony-phone">Phone</label>
                                    <input type="text" id="iei-testimony-phone" name="mobile" value="<?php echo e(old('mobile')); ?>" required="required" class="sm-form-control" />
                                </div>

                                <div class="col_half col_last">
                                    <label for="iei-testimony-org">Organization/Title <small>*</small></label>
                                    <input type="text" id="iei-testimony-org" name="company" value="<?php echo e(old('company')); ?>" required="required" class="required sm-form-control" />
                                </div>

                                <div class="clear"></div>
                                <div class="col_full">
                                    <label for="iei-testimony-message">Upload Photo <small>*</small></label>
                                    <input type="file" id="iei-testimony-file" name="image" required="required" class="required sm-form-control file" data-show-preview="false"/>
                                </div>

                                <div class="clear"></div>

                                <div class="col_full">
                                    <label for="iei-testimony-message">Feedback <small>*</small></label>
                                    <textarea class="required sm-form-control" id="iei-testimony-message" required="required" name="testimony" rows="6" cols="30"><?php echo e(old('testimony')); ?></textarea>
                                </div>
                                <div class="col_full">
                                    <button class="button button-3d nomargin" type="submit" id="iei-testimony-submit" value="submit">Publish Testimony</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        <!-- Modal Contact Form End -->
    </section><!-- end iei testimonials -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>