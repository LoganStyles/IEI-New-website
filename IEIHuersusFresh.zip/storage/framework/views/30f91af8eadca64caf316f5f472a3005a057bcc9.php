<?php  $title="$page->title";  ?>

<?php $__env->startSection('content'); ?>    
    <!-- Page Title ============================================= -->
    <section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url(<?php echo e(asset('/media/images/'.$page->breadcrumbs_background)); ?>); repeat: no-repeat; padding: 120px 0;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
        <div class="container clearfix text-white">
            <h1><?php echo e($page->title); ?></h1>
            <span><?php echo e($page->subtitle); ?></span>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Home</a></li>
                <?php if(!empty($page->parent)): ?>
                <li class="breadcrumb-item" aria-current="page"><?php echo e($page->parent); ?></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title); ?></li>
            </ol>
        </div>
    </section><!-- #page-title end -->
    <!-- Page Sub Menu ============================================= 
    <div id="page-menu">
        <div id="page-menu-wrap">
            <div class="container clearfix">
                <div class="menu-title"> <span><?php echo e($page->alias); ?></span></div>
                <div id="page-submenu-trigger"><i class="icon-reorder"></i></div>
            </div>
        </div>
    </div> #page-menu end -->        
    <!--================================ START SERVICE AREA =================================-->
    <section class="single-area responsive-content area-padding">
        <div class="service-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="single-content single--content">
                            <div class="single__img mb-50px">
                                <img src="<?php echo e(asset('/media/images/')); ?>/<?php echo e($strategy->image); ?>" alt="service image" class="img-single">
                            </div><!-- end single__img -->
                            <div class="iei-heading">
                                <h2 class="iei__title"><?php echo $page->content_title; ?></h2>
                                <p class="iei__desc audit-title mt-30px mb-40px"><?php echo $page->content; ?></p>
                            </div><!-- end iei-heading -->
                            <div class="single__img clearfix iei-single iei--single">
                                <div class="single__img-img" style="background-image: url(<?php echo e(asset('/media/images/')); ?>/<?php echo e($strategy->selection_criteria_image); ?>); padding: 120px 0;"></div><!-- end single__img-img -->
                                <div class="iei-heading">
                                    <h2 class="iei__title ml-5"><?php echo $strategy->selection_criteria_title; ?></h2>
                                    <p class="iei__desc mt-20px ml-5"><?php echo $strategy->selection_criteria_desc; ?></p>
                                </div>
                            </div><!-- end single__img -->
                            
                            
                            <div class="single__img clearfix mt-60px">
                                <div class="iei-heading single__service chart__title">
                                    <h2 class="iei__title"><?php echo $strategy->exit_strategy_title; ?></h2>
                                    <p class="iei__desc singlecases__desc2 mt-25px mb-30px"><?php echo $strategy->exit_strategy_desc; ?></p>
                                </div><!-- end iei-heading -->
                                <div class="single__chart line__chart" style="background-image: url(<?php echo e(asset('/media/images/')); ?>/<?php echo e($strategy->exit_strategy_image); ?>); padding: 120px 0;">
                                </div><!-- end single__chart -->
                            </div><!-- end single__img -->



                        </div><!-- end single-content -->
                    </div><!-- end col-md-8 -->


                    <div class="col-md-4">
                        <div class="side-bar">
                            <div class="side__shared mb-30px">
                                <h3 class="side__bar-title">Business Services</h3>
                                <ul class="side__bar-links">
                                    <li>
                                        <a href="<?php echo e(url('pension/schemes')); ?>">Retirement Advisory Service</a>
                                        <span class="fontello icon-angle-double-right"></span>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('pension/schemes')); ?>">Retirement planning Service</a>
                                        <span class="fontello icon-angle-double-right"></span>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('pension/schemes')); ?>">Voluntary Contribution Scheme</a>
                                        <span class="fontello icon-angle-double-right"></span>
                                    </li>
                                    
                                </ul>
                            </div><!-- end side__shared -->
                            <div class="side__shared help__shared help__bg mb-30px">
                                <div class="iei__help-center">
                                    <h3 class="side__bar-title__title"><?php echo $strategy->need_help_title; ?></h3>
                                    <p class="iei__help-desc__desc">
                                    <?php echo $strategy->need_help_desc; ?></p>
                                </div>
                            </div>
                            <div class="download__btn">
                                <a href="<?php echo e(url('resources/downloads')); ?>" class="download__btn-btn">
                                    Download Page <span class="fontello icon-angle-double-right"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================================ END SERVICE AREA =================================-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>