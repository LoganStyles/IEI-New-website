<?php $__env->startSection('content'); ?>
    <div class="card border-light mb-3 mt-3">
        <div class="card-header"><strong>Edit Page</strong></div>
            <div class="card-body">
                <div class="row">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success w-100">
                            <?php if(is_array(session()->get('success'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('success')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger w-100">
                            <?php if(is_array(session()->get('error'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('error')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.pages.strategy')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-12 control-label pl-0"><b>Image</b></label>
                            <div class="form-control">
                                <input id="image" type="file" name="image">
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('selection_criteria_title') ? ' has-error' : ''); ?>">
                            <label for="selection_criteria_title" class="col-md-12 control-label pl-0"><b>Criteria Title</b></label>
                            <input id="selection_criteria_title" type="text" class="form-control" name="selection_criteria_title" value="<?php echo e($page->selection_criteria_title); ?>" required>
                            <?php if($errors->has('selection_criteria_title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('selection_criteria_title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('selection_criteria_image') ? ' has-error' : ''); ?>">
                            <label for="selection_criteria_image" class="col-md-12 control-label pl-0"><b>Criteria Image</b></label>
                            <div class="form-control">
                                <input id="selection_criteria_image" type="file" name="selection_criteria_image">
                                <?php if($errors->has('selection_criteria_image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('selection_criteria_image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('selection_criteria_desc') ? ' has-error' : ''); ?>">
                            <label for="selection_criteria_desc" class="col-md-12 control-label pl-0"><b>Criteria Description</b></label>
                            <textarea id="selection_criteria_desc" class="form-control texteditor selection_criteria_desc" name="selection_criteria_desc"><?php echo $page->selection_criteria_desc; ?></textarea>
                            <?php if($errors->has('selection_criteria_desc')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('selection_criteria_desc')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('exit_strategy_title') ? ' has-error' : ''); ?>">
                            <label for="exit_strategy_title" class="col-md-12 control-label pl-0"><b>Exit Strategy Title</b></label>
                            <input id="exit_strategy_title" type="text" class="form-control" name="exit_strategy_title" value="<?php echo e($page->exit_strategy_title); ?>" required>
                            <?php if($errors->has('exit_strategy_title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('exit_strategy_title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('exit_strategy_desc') ? ' has-error' : ''); ?>">
                            <label for="exit_strategy_desc" class="col-md-12 control-label pl-0"><b>Exit Strategy Description</b></label>
                            <textarea id="exit_strategy_desc" class="form-control texteditor exit_strategy_desc" name="exit_strategy_desc"><?php echo $page->exit_strategy_desc; ?></textarea>
                            <?php if($errors->has('exit_strategy_desc')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('exit_strategy_desc')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('need_help_title') ? ' has-error' : ''); ?>">
                            <label for="need_help_title" class="col-md-12 control-label pl-0"><b>Need Help Title</b></label>
                            <input id="need_help_title" type="text" class="form-control" name="need_help_title" value="<?php echo e($page->need_help_title); ?>" required>
                            <?php if($errors->has('need_help_title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('need_help_title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('need_help_desc') ? ' has-error' : ''); ?>">
                            <label for="need_help_desc" class="col-md-12 control-label pl-0"><b>Need Help Description</b></label>
                            <textarea id="need_help_desc" class="form-control texteditor need_help_desc" name="need_help_desc"><?php echo $page->need_help_desc; ?></textarea>
                            <?php if($errors->has('need_help_desc')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('need_help_desc')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                                           

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save Page</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('select.page').change(function(){
            $(location).attr('href',"<?php echo e(url('office/pages/modify/')); ?>/"+$(this).val() );
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>