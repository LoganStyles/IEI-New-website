<?php  $title="$page->title";  ?>

<?php $__env->startSection('content'); ?>    
    <!-- Page Title ============================================= -->
    <section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url(<?php echo e(asset('/media/images/'.$page->breadcrumbs_background)); ?>); repeat: no-repeat; padding: 120px 0;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
        <div class="container clearfix text-white">
            <h1><?php echo e($page->title); ?></h1>
            <span><?php echo e($page->subtitle); ?></span>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Home</a></li>
                <?php if(!empty($page->parent)): ?>
                <li class="breadcrumb-item" aria-current="page"><?php echo e($page->parent); ?></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title); ?></li>
            </ol>
        </div>
    </section><!-- #page-title end -->
    <!-- Page Sub Menu ============================================= 
    <div id="page-menu">
        <div id="page-menu-wrap">
            <div class="container clearfix">
                <div class="menu-title"> <span><?php echo e($page->alias); ?></span></div>
                <div id="page-submenu-trigger"><i class="icon-reorder"></i></div>
            </div>
        </div>
    </div> #page-menu end -->
    <!-- Content ============================================= -->
    <section id="pension-calculator">
        <div class="content-wrap">
            <div class="container clearfix">
                <div class=" promo-center bottommargin">
                    <div class="pension-cal-widget">
                        <div class="promo promo-center">
                        <h4 style="font-weight: 400;">View and download our yearly reports and financial statements</h4>
                        </div>

                        <fieldset>
                            <div class="retirement-widget typography">
                                <div class="row">
                                    <div class="small-12 large-10 large-offset-1 columns">
                                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                            
                                        <!-- repeatable elements start -->
                                        <div class="small-12 medium-6 columns end">
                                            <div class="row">
                                                <div class="show-for-medium medium-3 large-2 columns">
                                                    <img src="<?php echo e(asset('/media/images/misc/images/')); ?>/<?php echo e($file->icon); ?>" alt="" width="84">
                                                </div>
                                                <div class="small-12 medium-9 large-10 columns">
                                                    <div class="content js-forms-content" style="height: 197px;">
                                                        <h4><a href="<?php echo e(asset('/uploads/documents/')); ?>/<?php echo e(strtolower(str_ireplace(' ','-',$file->category))); ?>/<?php echo e($file->file); ?>" target="_blank"><?php echo e($file->title); ?></a></h4>
                                                        <p><?php echo $file->description; ?></p>
                                                        <div>
                                                            <a class="button primary" href="<?php echo e(asset('/uploads/documents/')); ?>/<?php echo e(strtolower(str_ireplace(' ','-',$file->category))); ?>/<?php echo e($file->file); ?>" target="_blank">Download</a>
                                                            <small>File size: <strong>(<?php echo e($file->size); ?> KB)</strong></small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--row-->
                                            </div>
                                        </div>                                                               
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="line"></div>
                                        <?php $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                            
                                        <!-- repeatable elements start -->
                                        <div class="small-12 medium-6 columns end">
                                            <div class="row">
                                                <div class="show-for-medium medium-3 large-2 columns">
                                                    <img src="<?php echo e(asset('/media/images/misc/images/')); ?>/<?php echo e($file->icon); ?>" alt="" width="84">
                                                </div>
                                                <div class="small-12 medium-9 large-10 columns">
                                                    <div class="content js-forms-content" style="height: 197px;">
                                                        <h4><a href="<?php echo e(asset('/uploads/documents/')); ?>/<?php echo e(strtolower(str_ireplace(' ','-',$file->category))); ?>/<?php echo e($file->file); ?>" target="_blank"><?php echo e($file->title); ?></a></h4>
                                                        <p><?php echo $file->description; ?></p>
                                                        <div>
                                                            <a class="button primary" href="<?php echo e(asset('/uploads/documents/')); ?>/<?php echo e(strtolower(str_ireplace(' ','-',$file->category))); ?>/<?php echo e($file->file); ?>" target="_blank">Download</a>
                                                            <small>File size: <strong>(<?php echo e($file->size); ?> KB)</strong></small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--row-->
                                            </div>
                                        </div>                                                               
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="line"></div>
                                        <?php $__currentLoopData = $reportsrsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                            
                                        <!-- repeatable elements start -->
                                        <div class="small-12 medium-6 columns end">
                                            <div class="row">
                                                <div class="show-for-medium medium-3 large-2 columns">
                                                    <img src="<?php echo e(asset('/media/images/misc/images/')); ?>/<?php echo e($file->icon); ?>" alt="" width="84">
                                                </div>
                                                <div class="small-12 medium-9 large-10 columns">
                                                    <div class="content js-forms-content" style="height: 197px;">
                                                        <h4><a href="<?php echo e(asset('/uploads/documents/')); ?>/<?php echo e(strtolower(str_ireplace(' ','-',$file->category))); ?>/<?php echo e($file->file); ?>" target="_blank"><?php echo e($file->title); ?></a></h4>
                                                        <p><?php echo $file->description; ?></p>
                                                        <div>
                                                            <a class="button primary" href="<?php echo e(asset('/uploads/documents/')); ?>/<?php echo e(strtolower(str_ireplace(' ','-',$file->category))); ?>/<?php echo e($file->file); ?>" target="_blank">Download</a>
                                                            <small>File size: <strong>(<?php echo e($file->size); ?> KB)</strong></small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--row-->
                                            </div>
                                        </div>                                                               
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="line"></div>

                                    </div>
                                </div>
                            </div>
                        </fieldset>

                    </div>

                    <div class="promo promo-center">
                        <h3>Call us today at <span>+234.081.65722731,</span> <span>+234.081.39882060</span> or Email us at <span>cservice@ieianchorpensions.com </span></h3>
                        <span>We strive to provide Our Customers with Top Notch Support to make their Retirement Wonderful</span>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>