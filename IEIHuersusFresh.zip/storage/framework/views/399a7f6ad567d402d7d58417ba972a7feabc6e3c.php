<?php  $title="$page->title";  ?>

<?php $__env->startSection('content'); ?>    
    <!-- Page Title ============================================= -->
    <section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url(<?php echo e(asset('/media/images/'.$page->breadcrumbs_background)); ?>); repeat: no-repeat; padding: 120px 0;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
        <div class="container clearfix text-white">
            <h1><?php echo e($page->title); ?></h1>
            <span><?php echo e($page->subtitle); ?></span>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>">Home</a></li>
                <?php if(!empty($page->parent)): ?>
                <li class="breadcrumb-item" aria-current="page"><?php echo e($page->parent); ?></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title); ?></li>
            </ol>
        </div>
    </section><!-- #page-title end -->
    <!-- Page Sub Menu =============================================
    <div id="page-menu">
        <div id="page-menu-wrap">
            <div class="container clearfix">
                <div class="menu-title"> <span><?php echo e($page->alias); ?></span></div>
                <div id="page-submenu-trigger"><i class="icon-reorder"></i></div>
            </div>
        </div>
    </div> #page-menu end -->
    <!-- Content ============================================= -->
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">
                <div class="col-md-12 w3ls_banner_bottom_left w3ls_courses_left">
                    <div class="w3ls_courses_left_grids">
                        
                        <div class="w3ls_courses_left_grid">
                            
                        </div>
                    </div>

                    <div>
                        <h2></h2>
                        <div style="background-color: #042948; margin-top: 40px; border-top-left-radius: 10px; border-top-right-radius: 10px;"> <p class="product_icon_title" style="color:#fff; font-weight:600; font-size:1.5em;">RSA</p></div>
                        <table id="rsa_fund_table" class="datatable" style="width: 100%; margin-top: -30px;">
                            <thead>
                                <tr>
                                    <th class="text-left">Date</th>
                                    <th class="text-left">Annual Rate of Return</th>
                                    <th class="text-left">3 Year Rolling Average Return</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $rsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($rate->date); ?></td>
                                    <td><?php echo e($rate->annual); ?></td>
                                    <td><?php echo e($rate->triannual); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot></tfoot>
                        </table>
                    </div>
                    
                    <div style="margin-top: 3%;">
                        <div style="background-color: #042948; margin-top: 40px; border-top-left-radius: 10px; border-top-right-radius: 10px;"> <p class="product_icon_title" style="color:#fff; font-weight:600; font-size:1.5em;">Retiree</p></div>
                        <table id="retiree_fund_table" class="datatable" style="width: 100%; margin-top: -30px;">
                            <thead><tr>
                                    <th class="text-left">Date</th>
                                    <th class="text-left">Annual Rate of Return</th>
                                    <th class="text-left">3 Year Rolling Average Return</th>
                                </tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $retiree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($rate->date); ?></td>
                                    <td><?php echo e($rate->annual); ?></td>
                                    <td><?php echo e($rate->triannual); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot></tfoot>
                        </table>
                    </div>
                </div>
                            
                <div class="clearfix"> </div>
            </div>
        </div>
    </section><!-- #content end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>