<?php $__env->startSection('content'); ?>
    <div class="card border-light mb-3 mt-3">
        <div class="card-header"><strong>Edit Page</strong></div>
            <div class="card-body">
                <div class="row">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success w-100">
                            <?php if(is_array(session()->get('success'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('success')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger w-100">
                            <?php if(is_array(session()->get('error'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('error')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.pages.modify',$page->id)); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('page') ? ' has-error' : ''); ?>">
                            <label for="page" class="col-md-12 control-label pl-0"><b>Select Page</b></label>
                            <div class="">
                                <select class="form-control page">
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e(($p->id==$page->id)? 'selected':''); ?>><?php echo e($p->page); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('page') ? ' has-error' : ''); ?> mt-5">
                            <label for="page" class="col-md-12 control-label pl-0"><b>Page Name</b></label>
                            <div class="">
                                <input id="page" type="text" class="form-control" name="page" value="<?php echo e($page->page); ?>" required autofocus>
                                <?php if($errors->has('page')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('page')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-12 control-label pl-0"><b>Title</b></label>
                            <input id="title" type="text" class="form-control" name="title" value="<?php echo e($page->title); ?>" required>
                            <?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="subtitle" class="col-md-12 control-label pl-0"><b>Sub Title</b></label>
                            <input id="subtitle" type="subtitle" class="form-control" name="subtitle" value="<?php echo e($page->subtitle); ?>" required>
                            <?php if($errors->has('subtitle')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('subtitle')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('alias') ? ' has-error' : ''); ?>">
                            <label for="alias" class="col-md-12 control-label pl-0"><b>Page Alias</b></label>
                            <input id="alias" type="text" class="form-control" name="alias" value="<?php echo e($page->alias); ?>" required>
                            <?php if($errors->has('alias')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('alias')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>                        

                        <div class="form-group<?php echo e($errors->has('breadcrumbs_background') ? ' has-error' : ''); ?>">
                            <label for="breadcrumbs_background" class="col-md-12 control-label pl-0"><b>Breadcrumbs Background Image</b></label>
                            <div class="form-control">
                                <input id="breadcrumbs_background" type="file" name="breadcrumbs_background">
                                <?php if($errors->has('breadcrumbs_background')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('breadcrumbs_background')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('parent') ? ' has-error' : ''); ?>">
                            <label for="parent" class="col-md-12 control-label pl-0"><b>Menu</b></label>
                            <input id="parent" type="text" class="form-control" name="parent" value="<?php echo e($page->parent); ?>" required>
                            <?php if($errors->has('parent')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('parent')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-12 control-label pl-0"><b>Description</b></label>
                            <input id="description" type="text" class="form-control" name="description" value="<?php echo e($page->description); ?>" required>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('content_title') ? ' has-error' : ''); ?>">
                            <label for="content_title" class="col-md-12 control-label pl-0"><b>Content Title</b></label>
                            <textarea class="form-control d-none d-md-none content_title" name="content_title"><?php echo $page->content_title; ?></textarea>
                            <textarea id="content_title" class="form-control texteditor content_title" name="content_title"><?php echo $page->content_title; ?></textarea>
                            <?php if($errors->has('content_title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('content_title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
                            <label for="content" class="col-md-12 control-label pl-0"><b>Page Content</b></label>
                            <textarea class="form-control d-none d-md-none content" name="content"><?php echo $page->content; ?></textarea>
                            <textarea id="content" class="form-control texteditor content height" name="content"><?php echo $page->content; ?></textarea>
                            <?php if($errors->has('content')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('content')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save Page</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('select.page').change(function(){
            $(location).attr('href',"<?php echo e(url('office/pages/modify/')); ?>/"+$(this).val() );
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>