<?php $__env->startSection('content'); ?>
    <div class="card border-light mb-3 mt-3">
        <div class="card-header"><strong>Resources</strong> <a href="<?php echo e(route('office.resources.create', ['resources'])); ?>" class="btn btn-sm btn-success float-right" title="Add Resources"><i class="fas fa-plus"></i> Add  Resources</a></div>
            <div class="card-body">
                <div class="row">
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Resource</th>
                                <th>Page</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Resource</th>
                                <th>Page</th>
                                <th>Title</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>

                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resource->resource); ?></td>
                                <td><?php echo e($resource->page); ?></td>
                                <td><?php echo e($resource->description); ?></td>
                                <td> 
                                    <?php if($resource->resource!="Contacts" && $resource->resource!="Applications"): ?>
                                    <a href="<?php echo e(route('office.resources.create', [$resource->type])); ?>" class="btn btn-xs btn-success"><i class="fas fa-plus"></i> Add</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('office.resources.view', [$resource->type])); ?>" class="btn btn-xs btn-primary"><i class="fas fa-edit"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>