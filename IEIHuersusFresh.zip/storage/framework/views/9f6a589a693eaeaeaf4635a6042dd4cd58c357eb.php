<?php $__env->startSection('content'); ?>
    <div class="card border-light mb-3 mt-3">
        <div class="card-header"><strong>Manage <?php echo e(ucwords($resource->type)); ?></strong> <a href="<?php echo e(route('office.resources')); ?>" class="btn btn-sm btn-danger float-right" title="Go Back"><i class="fas fa-arrow-circle-left"></i> Back</a><?php echo ($resource->type!='contacts' && $resource->type!='applications')?'<a href="'.route("office.resources.create", [$resource->type]).'" class="btn btn-sm btn-success float-right mr-3"><i class="fas fa-plus"></i> Add  '.ucwords($resource->type) .'</a>':'' ?></div>
            <div class="card-body">
                <div class="row">
                    <?php if($resource->type=='applications'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Birthday</th>
                                <th>State</th>
                                <th>Position</th>
                                <th>Docs</th>
                                <th>Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Birthday</th>
                                <th>State</th>
                                <th>Position</th>
                                <th>Docs</th>
                                <th>Date</th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->first_name); ?> <?php echo e($resource->last_name); ?></td>
                                <td><?php echo e($resourc->email); ?></td>
                                <td><?php echo e($resourc->mobile); ?></td>
                                <td><?php echo e($resourc->birthday); ?></td>
                                <td><?php echo e($resourc->state); ?></td>
                                <td><?php echo e($resourc->position); ?></td>
                                <td> 
                                    <a href="<?php echo e(asset('/uploads/careers/').'/'.$resourc->cv); ?>" target="_blank" class="btn btn-xs btn-danger p-2" title="View CV"><i class="fas fa-file-pdf fa-2x"></i></a>
                                    <a href="<?php echo e(asset('/uploads/careers/').'/'.$resourc->letter); ?>" target="_blank" class="btn btn-xs btn-info p-2" title="View Cover Letter"><i class="fas fa-file-word fa-2x"></i></a>
                                </td>
                                <td><?php echo e($resource->created_at); ?></td>
                                <td> 
                                    <?php if(Auth::user()->id==1): ?>
                                    <a data-href="<?php echo e(route('office.resources.resource.delete', ['type'=>$resource->type,'id'=>$resourc->id])); ?>" class="btn btn-xs btn-danger del"><i class="fas fa-trash text-white"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='awards'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Award</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Title</th>
                                <th>Award</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->title); ?></td>
                                <td><?php echo e($resourc->award); ?></td>
                                <td><?php echo e($resourc->description); ?></td>
                                <td> 
                                    <a href="<?php echo e(asset('/media/images/awards/').'/'.$resourc->image); ?>" target="_blank" class="btn btn-xs btn-warning p-2 rounded" title="View Award Image"><img src="<?php echo e(asset('/media/images/awards/').'/'.$resourc->image); ?>" class="img-responsive rounded mx-auto d-block" alt="Award Image" itemprop="image" width="50"></a>
                                </td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Award"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <?php if($resource->type=='branches'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>State</th>
                                <th>Personnel</th>
                                <th>Address</th>
                                <th>Mobile</th>
                                <th>Telephone</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Title</th>
                                <th>State</th>
                                <th>Personnel</th>
                                <th>Address</th>
                                <th>Mobile</th>
                                <th>Telephone</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->title); ?></td>
                                <td><?php echo e($resourc->state); ?></td>
                                <td><?php echo e($resourc->personnel); ?></td>
                                <td><?php echo e($resourc->address); ?></td>
                                <td><?php echo e($resourc->mobile); ?></td>
                                <td><?php echo e($resourc->phone); ?></td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Branches"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <?php if($resource->type=='contacts'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Pin</th>
                                <th>Employer</th>
                                <th>Subject</th>
                                <th>Type</th>
                                <th>Message</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Pin</th>
                                <th>Employer</th>
                                <th>Subject</th>
                                <th>Type</th>
                                <th>Message</th>
                                <th>Date</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resource->name); ?></td>
                                <td><?php echo e($resource->email); ?></td>
                                <td><?php echo e($resource->mobile); ?></td>
                                <td><?php echo e($resource->pin); ?></td>
                                <td><?php echo e($resource->employer); ?></td>
                                <td><?php echo e($resource->subject); ?></td>
                                <td><?php echo e($resource->type); ?></td>
                                <td><?php echo e($resource->message); ?></td>                                
                                <td><?php echo e($resource->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='files'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Size</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>File</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Title</th>
                                <th>Size</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>File</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->title); ?></td>
                                <td><?php echo e($resourc->size); ?></td>
                                <td><?php echo e($resourc->category); ?></td>
                                <td><?php echo e($resourc->description); ?></td>
                                <td> 
                                    <a href="<?php echo e(asset('/uploads/documents/').'/'. strtolower(str_ireplace(' ','-',$resourc->category)).'/'. $resourc->file); ?>" target="_blank" class="btn btn-xs btn-danger p-2" title="View File"><i class="fas fa-file-pdf fa-2x"></i></a>
                                </td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>                    
                    
                    <?php if($resource->type=='faqs'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Question</th>
                                <th>Answer</th>
                                <th>Category</th>
                                <th>Display</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Question</th>
                                <th>Answer</th>
                                <th>Category</th>
                                <th>Visibility</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->question); ?></td>
                                <td><?php echo e($resourc->answer); ?></td>
                                <td><?php echo e($resourc->category); ?></td>
                                <td><?php echo e(($resourc->display)? 'Visible' :'Disabled'); ?></td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='jobs'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Requirements</th>
                                <th>Needs</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Requirements</th>
                                <th>Needs</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->title); ?></td>
                                <td><?php echo $resourc->description; ?></td>
                                <td><?php echo $resourc->requirements; ?></td>
                                <td><?php echo $resourc->needs; ?></td>
                                <td><?php echo e($resourc->status); ?></td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='resources'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Resource</th>
                                <th>Page</th>
                                <th>Description</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Resource</th>
                                <th>Page</th>
                                <th>Description</th>
                                <th>Date</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->resource); ?></td>
                                <td><?php echo e($resourc->page); ?></td>
                                <td><?php echo e($resourc->description); ?></td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='services'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->title); ?></td>
                                <td><?php echo e($resourc->description); ?></td>
                                <td>
                                    <a href="<?php echo e(asset('/media/images/misc/').'/'.$resourc->image); ?>" target="_blank" class="btn btn-xs btn-danger p-2 rounded" title="View Service Image"><img src="<?php echo e(asset('/media/images/misc/').'/'.$resourc->image); ?>" class="img-responsive rounded mx-auto d-block" alt="Award Image" itemprop="image" width="50"></a>
                                </td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='teams'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Image</th>
                                <th>Profile</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Image</th>
                                <th>Profile</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->name); ?></td>
                                <td><?php echo e($resourc->position); ?></td>
                                <td>
                                    <a href="<?php echo e(asset('/media/images/team/').'/'.$resourc->image); ?>" target="_blank" class="btn btn-xs btn-danger p-2 rounded" title="View Profile Image"><img src="<?php echo e(asset('/media/images/team/').'/'.$resourc->image); ?>" class="img-responsive rounded mx-auto d-block" alt="Award Image" itemprop="image" width="50"></a>
                                </td>
                                <td><?php echo $resourc->profile; ?></td>
                                <td><?php echo $resourc->category; ?></td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='testimonials'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Company</th>
                                <th>Testimony</th>
                                <th>Image</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Company</th>
                                <th>Testimony</th>
                                <th>Image</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->name); ?></td>
                                <td><?php echo e($resourc->company); ?></td>
                                <td><?php echo e($resourc->testimony); ?></td>
                                <td>
                                    <a href="<?php echo e(asset('/media/images/testimonials/').'/'.$resourc->image); ?>" target="_blank" class="btn btn-xs btn-danger p-2 rounded" title="View Profile Image"><img src="<?php echo e(asset('/media/images/testimonials/').'/'.$resourc->image); ?>" class="img-responsive rounded mx-auto d-block" alt="View Testimonial Image" itemprop="image" width="50"></a>
                                </td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    
                    <?php if($resource->type=='history'): ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                    <thead>
                            <tr>
                                <th>RSA Fund I</th>
                                <th>RSA Fund II</th>
                                <th>RSA Fund III</th>
                                <th>RSA Fund IV</th>
                                <th>Report Date</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>RSA Fund I</th>
                                <th>RSA Fund II</th>
                                <th>RSA Fund III</th>
                                <th>RSA Fund IV</th>
                                <th>Report Date</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resourc->fundi); ?></td>
                                <td><?php echo e($resourc->fundii); ?></td>
                                <td><?php echo e($resourc->fundiii); ?></td>
                                <td><?php echo e($resourc->fundiv); ?></td>
                                <td><?php echo e($resourc->date); ?></td>
                                <td><?php echo e($resourc->created_at); ?></td>
                                <td> 
                                    <a href="<?php echo e(route('office.resources.resource.modify', [$resource->type,$resourc->id])); ?>" class="btn btn-xs btn-primary p-2 mx-auto" title="View Files"><i class="fas fa-eye"></i> View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>