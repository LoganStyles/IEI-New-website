<?php $__env->startSection('content'); ?>
    <div class="card border-light mb-3 mt-3">
        <div class="card-header"><strong>View/Edit <?php echo e(ucwords($resource->type)); ?></strong> <a href="<?php echo e(route('office.resources.view',[$resource->type])); ?>" class="btn btn-sm btn-danger float-right" title="Go Back"><i class="fas fa-arrow-circle-left"></i> Back</a></div>
            <div class="card-body">
                <div class="row">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success w-100">
                            <?php if(is_array(session()->get('success'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('success')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger w-100">
                            <?php if(is_array(session()->get('error'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('error')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if($resource->type=='awards'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>"  enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-12 control-label pl-0"><b>Title</b></label>
                            <div class="">
                                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($selected->title); ?>" required autofocus>
                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('award') ? ' has-error' : ''); ?>">
                            <label for="award" class="col-md-12 control-label pl-0"><b>Award</b></label>
                            <input id="award" type="text" class="form-control" name="award" value="<?php echo e($selected->award); ?>" required="required">
                            <?php if($errors->has('award')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('award')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-12 control-label pl-0"><b>Description</b></label>
                            <textarea id="description" class="form-control texteditor" name="description"><?php echo e($selected->description); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-12 control-label pl-0"><b>Image</b></label>
                            <div class="form-control">
                                <input id="image" type="file" name="image">
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='branches'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-12 control-label pl-0"><b>Branch Title</b></label>
                            <div class="">
                                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($selected->title); ?>" required autofocus>
                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                            <label for="state" class="col-md-12 control-label pl-0"><b>Branch State</b></label>
                            <select name="state" tabindex="9" class="form-control required"  required="required">
                                <option>-- Select State --</option>
                                <option value="Abia" <?php echo e(($selected->state == "Abia")?'selected="selected"':''); ?>>Abia</option>
                                <option value="Adamawa" <?php echo e(($selected->state == "Adamawa")?'selected="selected"':''); ?>>Adamawa</option>
                                <option value="Anambra" <?php echo e(($selected->state == "Anambra")?'selected="selected"':''); ?>>Anambra</option>
                                <option value="Akwa Ibom" <?php echo e(($selected->state == "Akwa Ibom")?'selected="selected"':''); ?>>Akwa Ibom</option>
                                <option value="Bauchi" <?php echo e(($selected->state == "Bauchi")?'selected="selected"':''); ?>>Bauchi</option>
                                <option value="Bayelsa" <?php echo e(($selected->state == "Bayelsa")?'selected="selected"':''); ?>>Bayelsa</option>
                                <option value="Benue" <?php echo e(($selected->state == "Benue")?'selected="selected"':''); ?>>Benue</option>
                                <option value="Borno" <?php echo e(($selected->state == "Borno")?'selected="selected"':''); ?>>Borno</option>
                                <option value="Cross River" <?php echo e(($selected->state == "Cross River")?'selected="selected"':''); ?>>Cross River</option>
                                <option value="Delta" <?php echo e(($selected->state == "Delta")?'selected="selected"':''); ?>>Delta</option>
                                <option value="Ebonyi" <?php echo e(($selected->state == "Ebonyi")?'selected="selected"':''); ?>>Ebonyi</option>
                                <option value="Enugu" <?php echo e(($selected->state == "Enugu")?'selected="selected"':''); ?>>Enugu</option>
                                <option value="Edo" <?php echo e(($selected->state == "Edo")?'selected="selected"':''); ?>>Edo</option>
                                <option value="Ekiti" <?php echo e(($selected->state == "Ekiti")?'selected="selected"':''); ?>>Adamawa</option>
                                <option value="FCT - Abuja" <?php echo e(($selected->state == "FCT - Abuja")?'selected="selected"':''); ?>>FCT - Abuja</option>
                                <option value="Gombe" <?php echo e(($selected->state == "Gombe")?'selected="selected"':''); ?>>Gombe</option>
                                <option value="Imo" <?php echo e(($selected->state == "Imo")?'selected="selected"':''); ?>>Imo</option>
                                <option value="Jigawa" <?php echo e(($selected->state == "Jigawa")?'selected="selected"':''); ?>>Jigawa</option>
                                <option value="Kaduna" <?php echo e(($selected->state == "Kaduna")?'selected="selected"':''); ?>>Kaduna</option>
                                <option value="Kano" <?php echo e(($selected->state == "Kano")?'selected="selected"':''); ?>>Kano</option>
                                <option value="Katsina" <?php echo e(($selected->state == "Katsina")?'selected="selected"':''); ?>>Katsina</option>
                                <option value="Kebbi" <?php echo e(($selected->state == "Kebbi")?'selected="selected"':''); ?>>Kebbi</option>
                                <option value="Kogi" <?php echo e(($selected->state == "Kogi")?'selected="selected"':''); ?>>Kogi</option>
                                <option value="Kwara" <?php echo e(($selected->state == "Kwara")?'selected="selected"':''); ?>>Kwara</option>
                                <option value="Lagos" <?php echo e(($selected->state == "Lagos")?'selected="selected"':''); ?>>Lagos</option>
                                <option value="Nasarawa" <?php echo e(($selected->state == "Nasarawa")?'selected="selected"':''); ?>>Nasarawa</option>
                                <option value="Niger" <?php echo e(($selected->state == "Niger")?'selected="selected"':''); ?>>Niger</option>
                                <option value="Ogun" <?php echo e(($selected->state == "Abia")?'selected="selected"':''); ?>>Ogun</option>
                                <option value="Ondo" <?php echo e(($selected->state == "Ondo")?'selected="selected"':''); ?>>Ondo</option>
                                <option value="Osun" <?php echo e(($selected->state == "Osun")?'selected="selected"':''); ?>>Osun</option>
                                <option value="Oyo" <?php echo e(($selected->state == "Oyo")?'selected="selected"':''); ?>>Oyo</option>
                                <option value="Plateau" <?php echo e(($selected->state == "Plateau")?'selected="selected"':''); ?>>Plateau</option>
                                <option value="Rivers" <?php echo e(($selected->state == "Rivers")?'selected="selected"':''); ?>>Rivers</option>
                                <option value="Sokoto" <?php echo e(($selected->state == "Sokoto")?'selected="selected"':''); ?>>Sokoto</option>
                                <option value="Taraba" <?php echo e(($selected->state == "Taraba")?'selected="selected"':''); ?>>Taraba</option>
                                <option value="Yobe" <?php echo e(($selected->state == "Yobe")?'selected="selected"':''); ?>>Yobe</option>
                                <option value= "Zamfara" <?php echo e(($selected->state == "Zamfara")?'selected="selected"':''); ?>>Yobe</option>
                            </select>
                            <?php if($errors->has('state')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('state')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('personnel') ? ' has-error' : ''); ?>">
                            <label for="personnel" class="col-md-12 control-label pl-0"><b>Branch Contact Person</b></label>
                            <input id="personnel" type="text" class="form-control" name="personnel" value="<?php echo e($selected->personnel); ?>" required="required">
                            <?php if($errors->has('personnel')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('personnel')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                            <label for="address" class="col-md-12 control-label pl-0"><b>Branch Address</b></label>
                            <textarea id="address" class="form-control texteditor" name="address"><?php echo e($selected->address); ?></textarea>
                            <?php if($errors->has('address')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('address')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
                            <label for="mobile" class="col-md-12 control-label pl-0"><b>Branch Mobile Number</b></label>
                            <input id="mobile" type="text" class="form-control" name="mobile" value="<?php echo e($selected->mobile); ?>" required="required">
                            <?php if($errors->has('mobile')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('mobile')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                            <label for="phone" class="col-md-12 control-label pl-0"><b>Branch Telephone Number</b></label>
                            <input id="phone" type="text" class="form-control" name="phone" value="<?php echo e($selected->phone); ?>" required="required">
                            <?php if($errors->has('mobile')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('phone')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('page') ? ' has-error' : ''); ?>">
                            <label for="display" class="col-md-12 control-label pl-0"><b>Make Visible in Frontend</b></label>
                            <div class="">
                                <select class="form-control" name="display">
                                    <option value="0" <?php echo e(($selected->display==0)?'selected="selected"':''); ?>>Disable</option>
                                    <option value="1"  <?php echo e(($selected->display==1)?'selected="selected"':''); ?>>Visible</option>
                                </select>
                            </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='files'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>"  enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-12 control-label pl-0"><b>File Title</b></label>
                            <div class="">
                                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($selected->title); ?>" required autofocus>
                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                            <label for="category" class="col-md-12 control-label pl-0"><b>Category</b></label>
                            <div class="">
                                <select class="form-control category" name="category">
                                    <option value="Checklist Requirement" <?php echo e(($selected->category=='Checklist Requirement')?'selected="selected"':''); ?>>Checklist Requirement</option>
                                    <option value="Data Re-capture" <?php echo e(($selected->category=='Data Re-capture')?'selected="selected"':''); ?>>Data Re-capture</option>
                                    <option value="Letters" <?php echo e(($selected->category=='Letters')?'selected="selected"':''); ?>>Letter</option>
                                    <option value="Multifund" <?php echo e(($selected->category=='Multifund')?'selected="selected"':''); ?>>Multifund</option>
                                    <option value="Guidelines" <?php echo e(($selected->category=='Guidelines')?'selected="selected"':''); ?>>Guidelines</option>
                                    <option value="Newsletters" <?php echo e(($selected->category=='Newsletters')?'selected="selected"':''); ?>>Newsletters</option>
                                    <option value="Forms" <?php echo e(($selected->category=='Forms')?'selected="selected"':''); ?>>Forms</option>
                                    <option value="Financial Statement" <?php echo e(($selected->category=='Financial Statement')?'selected="selected"':''); ?>>Financial Statement</option>
                                </select>
                            </div>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('file') ? ' has-error' : ''); ?>">
                            <label for="file" class="col-md-12 control-label pl-0"><b>Upload File</b></label>
                            <div class="form-control">
                                <input id="file" type="file" name="file">
                                <?php if($errors->has('file')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('file')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-12 control-label pl-0"><b>Description</b></label>
                            <textarea id="description" class="form-control texteditor" name="description"><?php echo e($selected->description); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='faqs'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                            <label for="category" class="col-md-12 control-label pl-0"><b>Category</b></label>
                            <div class="">
                                <select class="form-control" name="category">
                                    <option value="General FAQs" <?php echo e(($selected->category=='General FAQs')?'selected="selected"':''); ?>>General FAQs</option>
                                    <option value="My Retirement Savings Account" <?php echo e(($selected->category=='My Retirement Savings Account')?'selected="selected"':''); ?>>My Retirement Savings Account</option>
                                    <option value="About My Retirement" <?php echo e(($selected->category=='About My Retirement')?'selected="selected"':''); ?>>About My Retirement</option>
                                    <option value="Multi Funds" <?php echo e(($selected->category=='Multi Funds')?'selected="selected"':''); ?>>Multi Funds</option>
                                    <option value="Micro Pension Funds" <?php echo e(($selected->category=='Micro Pension Funds')?'selected="selected"':''); ?>>Micro Pension Funds</option>
                                </select>
                            </div>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('question') ? ' has-error' : ''); ?>">
                            <label for="question" class="col-md-12 control-label pl-0"><b>Question</b></label>
                            <textarea class="form-control d-none d-md-none question" name="question"><?php echo e($selected->question); ?></textarea>
                            <textarea id="question" class="form-control texteditor question" name="question"><?php echo e($selected->question); ?></textarea>
                            <?php if($errors->has('question')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('question')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('answer') ? ' has-error' : ''); ?>">
                            <label for="answer" class="col-md-12 control-label pl-0"><b>Answer</b></label>
                            <textarea class="form-control d-none d-md-none answer" name="answer"><?php echo e($selected->answer); ?></textarea>
                            <textarea id="answer" class="form-control texteditor answer" name="answer"><?php echo e($selected->answer); ?></textarea>
                            <?php if($errors->has('answer')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('answer')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('page') ? ' has-error' : ''); ?>">
                            <label for="display" class="col-md-12 control-label pl-0"><b>Make Visible in Frontend</b></label>
                            <div class="">
                                <select class="form-control" name="display">
                                    <option value="0" <?php echo e(($selected->display==0)?'selected="selected"':''); ?>>Disable</option>
                                    <option value="1"  <?php echo e(($selected->display==1)?'selected="selected"':''); ?>>Visible</option>
                                </select>
                            </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='jobs'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-12 control-label pl-0"><b>Vacancy</b></label>
                            <div class="">
                                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($selected->title); ?>" required autofocus>
                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-12 control-label pl-0"><b>Description</b></label>
                            <textarea id="description" class="form-control texteditor description" name="description"><?php echo e($selected->description); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('requirements') ? ' has-error' : ''); ?>">
                            <label for="roles" class="col-md-12 control-label pl-0"><b>Requirements</b></label>
                            <textarea id="requirements" class="form-control texteditor requirements" name="requirements"><?php echo e($selected->requirements); ?></textarea>
                            <?php if($errors->has('requirements')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('requirements')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('roles') ? ' has-error' : ''); ?>">
                            <label for="roles" class="col-md-12 control-label pl-0"><b>Roles</b></label>
                            <textarea id="roles" class="form-control texteditor roles" name="roles"><?php echo e($selected->roles); ?></textarea>
                            <?php if($errors->has('roles')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('roles')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('needs') ? ' has-error' : ''); ?>">
                            <label for="needs" class="col-md-12 control-label pl-0"><b>Needs</b></label>
                            <textarea id="needs" class="form-control texteditor needs" name="needs"><?php echo e($selected->needs); ?></textarea>
                            <?php if($errors->has('needs')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('needs')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('page') ? ' has-error' : ''); ?>">
                            <label for="display" class="col-md-12 control-label pl-0"><b>Make Visible in Frontend</b></label>
                            <div class="">
                                <select class="form-control" name="status">
                                    <option value="0" <?php echo e(($selected->status==0)?'selected="selected"':''); ?>>Disable</option>
                                    <option value="1" <?php echo e(($selected->status==1)?'selected="selected"':''); ?>>Visible</option>
                                </select>
                            </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='resources'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('resource') ? ' has-error' : ''); ?>">
                            <label for="resource" class="col-md-12 control-label pl-0"><b>Resource</b></label>
                            <div class="">
                                <input id="resource" type="text" class="form-control" name="resource" value="<?php echo e($selected->resource); ?>" required autofocus>
                                <?php if($errors->has('resource')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('resource')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('page') ? ' has-error' : ''); ?>">
                            <label for="page" class="col-md-12 control-label pl-0"><b>Page</b></label>
                            <div class="">
                                <input id="page" type="text" class="form-control" name="page" value="<?php echo e($selected->page); ?>" required="required">
                                <?php if($errors->has('page')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('page')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                            <label for="type" class="col-md-12 control-label pl-0"><b>Slug</b></label>
                            <div class="">
                                <input id="type" type="text" class="form-control" name="type" value="<?php echo e($selected->type); ?>" required="required">
                                <?php if($errors->has('type')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('type')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-12 control-label pl-0"><b>Description</b></label>
                            <div class="">
                                <input id="description" type="text" class="form-control" name="description" value="<?php echo e($selected->description); ?>" required="required">
                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='services'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>"  enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-12 control-label pl-0"><b>Title</b></label>
                            <div class="">
                                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($selected->title); ?>" required autofocus>
                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-12 control-label pl-0"><b>Description</b></label>
                            <textarea id="description" class="form-control texteditor" name="description"><?php echo e($selected->description); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-12 control-label pl-0"><b>Award Image</b></label>
                            <div class="form-control">
                                <input id="image" type="file" name="image">
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='teams'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>"  enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-12 control-label pl-0"><b>Name</b></label>
                            <div class="">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($selected->name); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('position') ? ' has-error' : ''); ?>">
                            <label for="position" class="col-md-12 control-label pl-0"><b>Position</b></label>
                            <div class="">
                                <input id="position" type="text" class="form-control" name="position" value="<?php echo e($selected->position); ?>" required="required">
                                <?php if($errors->has('position')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('position')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                            <label for="category" class="col-md-12 control-label pl-0"><b>Category</b></label>
                            <div class="">
                                <select class="form-control" name="category">
                                    <option value="Director" <?php echo e(($selected->category=='Director')?'selected="selected"':''); ?>>Director</option>
                                    <option value="Management" <?php echo e(($selected->category=='Management')?'selected="selected"':''); ?>>Management</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('profile') ? ' has-error' : ''); ?>">
                            <label for="profile" class="col-md-12 control-label pl-0"><b>Profile</b></label>
                            <textarea class="form-control d-none d-md-none profile" name="profile"><?php echo e($selected->profile); ?></textarea>
                            <textarea id="profile" class="form-control texteditor profile" name="profile"><?php echo e($selected->profile); ?></textarea>
                            <?php if($errors->has('profile')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('profile')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-12 control-label pl-0"><b>Image</b></label>
                            <div class="form-control">
                                <input id="image" type="file" name="image">
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='testimonials'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>"  enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-12 control-label pl-0"><b>Name</b></label>
                            <div class="">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($selected->name); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
                            <label for="company" class="col-md-12 control-label pl-0"><b>Company</b></label>
                            <div class="">
                                <input id="company" type="text" class="form-control" name="company" value="<?php echo e($selected->company); ?>" required="required">
                                <?php if($errors->has('company')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('company')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('testimony') ? ' has-error' : ''); ?>">
                            <label for="testimony" class="col-md-12 control-label pl-0"><b>Profile</b></label>
                            <textarea id="testimony" class="form-control texteditor testimony" name="testimony"><?php echo e($selected->testimony); ?></textarea>
                            <?php if($errors->has('testimony')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('testimony')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-12 control-label pl-0"><b>Image</b></label>
                            <div class="form-control">
                                <input id="image" type="file" name="image">
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php if($resource->type=='history'): ?>
                    <form class="form-horizontal col-md-12" method="POST" action="<?php echo e(route('office.resources.resource.modify',[$resource->type,$selected->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('fundi') ? ' has-error' : ''); ?>">
                            <label for="fundi" class="col-md-12 control-label pl-0"><b>Fund I</b></label>
                            <div class="">
                                <input id="fundi" type="text" class="form-control" name="fundi" value="<?php echo e($selected->fundi); ?>" required autofocus>
                                <?php if($errors->has('fundi')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fundi')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('fundii') ? ' has-error' : ''); ?>">
                            <label for="fundii" class="col-md-12 control-label pl-0"><b>Fund II</b></label>
                            <div class="">
                                <input id="fundii" type="text" class="form-control" name="fundii" value="<?php echo e($selected->fundii); ?>" required="required">
                                <?php if($errors->has('fundii')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fundii')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('fundiii') ? ' has-error' : ''); ?>">
                            <label for="fundiii" class="col-md-12 control-label pl-0"><b>Fund III</b></label>
                            <div class="">
                                <input id="fundiii" type="text" class="form-control" name="fundiii" value="<?php echo e($selected->fundiii); ?>" required="required">
                                <?php if($errors->has('fundiii')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fundiii')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('fundiv') ? ' has-error' : ''); ?>">
                            <label for="fundiv" class="col-md-12 control-label pl-0"><b>Fund IV</b></label>
                            <div class="">
                                <input id="fundiv" type="text" class="form-control" name="fundiv" value="<?php echo e($selected->fundiv); ?>" required="required">
                                <?php if($errors->has('fundiv')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fundiv')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('fundiv') ? ' has-error' : ''); ?>">
                            <label for="date" class="col-md-12 control-label pl-0"><b>Report Date</b></label>
                            <div class="">
                                <input id="date" type="text" class="form-control" name="date" value="<?php echo e($selected->date); ?>" required="required">
                                <?php if($errors->has('date')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary submit">Save <?php echo e(ucwords($resource->type)); ?></button>
                        </div>
                    </form>
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>