<?php $__env->startSection('content'); ?>
    <div class="card border-light mb-3 mt-3">
        <div class="card-header"><strong>View Menu</strong></div>
            <div class="card-body">
                <div class="row">
                    
                <?php if(session()->has('success')): ?>
                        <div class="alert alert-success w-100">
                            <?php if(is_array(session()->get('success'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('success')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger w-100">
                            <?php if(is_array(session()->get('error'))): ?>
                            <ul>
                                <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php else: ?>
                                <?php echo e(session()->get('error')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <table class="datatable table table-striped table-hover table-bordered table-responsive w-100">
                    <colgroup span="3"></colgroup>
                        <thead>
                            <tr>
                            <th scope="col">Page</th>
                            <th scope="col">Link</th>
                            <th scope="col">Last Updated</th>
                            <th scope="col">Action</th>
                            </tr>
                        </thead>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($menu->sub): ?>
                                <tr>
                                    <th scope="row"><?php echo e($menu->page); ?></th>
                                    <th>Sub Menu</th>
                                    <th>Link</th>
                                    <th>
                                        <a href="<?php echo e(route('office.menu.modify', ['type'=>$menu->slug.'::main'])); ?>" class="btn btn-xs btn-primary"><i class="fas fa-edit"></i> Edit <?php echo e($menu->page); ?></a>
                                        <a data-href="<?php echo e(route('office.menu.delete', ['type'=>$menu->slug.'::main'])); ?>" class="btn btn-xs btn-danger del text-white"><i class="fas fa-trash"></i> Delete</a>
                                    </th>
                                </tr>
                                <tr>
                                    <th rowspan="<?php echo e(count($menu->menu)+1); ?>" scope="rowgroup"></th>
                                </tr>
                                <?php $__currentLoopData = $menu->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sub->page); ?></td>
                                    <td><?php echo e($sub->url); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('office.menu.modify', ['type'=>$sub->slug.'::sub'])); ?>" class="btn btn-xs btn-primary"><i class="fas fa-edit"></i> Edit</a>
                                        <a data-href="<?php echo e(route('office.menu.delete', ['type'=>$sub->slug.'::sub'])); ?>" class="btn btn-xs btn-danger del text-white"><i class="fas fa-trash"></i> Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td><?php echo e($menu->page); ?></td>
                                    <td><?php echo e($menu->url); ?></td>
                                    <td><?php echo e($menu->updated_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('office.menu.modify', ['type'=>$menu->slug.'::main'])); ?>" class="btn btn-xs btn-primary"><i class="fas fa-edit"></i> Edit</a>
                                        <a data-href="<?php echo e(route('office.menu.delete', ['type'=>$menu->slug.'::main'])); ?>" class="btn btn-xs btn-danger del text-white"><i class="fas fa-trash"></i> Delete</a>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>